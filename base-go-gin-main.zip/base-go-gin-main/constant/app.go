package constant

const (
	DefaultDataLen = 10
)
