package domain

type TypeGender string

const (
	GenderMale   TypeGender = "m"
	GenderFemale TypeGender = "f"
)
